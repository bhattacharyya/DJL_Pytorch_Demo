op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1597.Module,
    input: Tensor) -> Tensor:
    _0 = torch.addmm(self.bias, input, torch.t(self.weight), beta=1, alpha=1)
    return _0
